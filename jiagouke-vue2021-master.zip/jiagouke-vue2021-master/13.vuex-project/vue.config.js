module.exports = {
    // 可以直接调试源代码 通过npm run dev  --sourcemap
    // 可以配置具体执行的vue的入口文件 默认采用的是vue.runtime.esm.js
}