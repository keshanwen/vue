<template>
  <div class="home">
   <h1>This is a home page</h1>
  </div>
</template>

