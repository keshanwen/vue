export default {
    render(){
        return <a>link</a>
    }
}