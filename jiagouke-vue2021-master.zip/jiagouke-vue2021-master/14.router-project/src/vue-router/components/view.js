export default {
    render(){
        return <h1>view</h1>
    }
}