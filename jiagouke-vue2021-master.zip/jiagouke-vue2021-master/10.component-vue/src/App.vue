<template>
  <div id="app">
    <!-- <ClickOutSide></ClickOutSide> -->
    <!-- <VueLazyLoad></VueLazyLoad> -->
    <Form></Form>
  </div>
</template>

<script>
// import ClickOutSide from  '@/components/click-outside'
// import VueLazyLoad from '@/components/vue-lazyload.vue'
import Form from "@/components/form.vue";
export default {
  // components:{
  // ClickOutSide,
  // VueLazyLoad
  // }
  components: {
    Form,
  },
};
</script>

<style>
</style>
