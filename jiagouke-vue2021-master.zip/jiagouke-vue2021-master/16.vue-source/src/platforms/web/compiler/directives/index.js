import model from './model'
import text from './text'
import html from './html'

export default {
  model,
  text,
  html
}
