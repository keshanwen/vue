<template>
    <div>bar</div>
</template>

<style scoped="true">
div{
    background:red
}
</style>